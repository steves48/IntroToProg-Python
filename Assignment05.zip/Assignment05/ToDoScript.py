"""

Title: Todo List and Text File

Dev:  SJSarewitz

Date:  Nov. 16, 2018

Desc:  This script creates a household "to do" list by creating a text file and writing 2 tasks
and their priorities to the file.  The script then extracts the data from the file and loads
it into a list of dictionaries.  Then, the script gives the user options to:
1, Display the data from the list;
2, Add new tasks to the list; 3, Remove tasks from the list; 4, Write the tasks in the
list to the text file
(previous data in the text file will be overwritten); and 5, Exit from the program.

ChangeLog: (Who, What, When)
    SJSarewitz, Nov. 16, 2018, Created script

"""

#--------------Data----------------------------------#
dictNew = {}
lstWork = []

#--------------Processing----------------------------#

#Create text file, and write the initial data to it:
fileHandle = open("Todo.txt", "w")
fileHandle.write("Clean house,low\n")
fileHandle.write("Pay bills,high\n")
fileHandle.close()

#Load the initial data from the text file to dictionary 'dictNew', and append the dictionary
#to empty list 'lstWork'

fileHandle = open("Todo.txt", "r")

for line in fileHandle:
    # Split each line into the task and the priority
    strTask = line.split(",")[0]
    strPriority = line.split(",")[1]
    # Remove the '\n' character from the end of the line [Python seems to treat '\n' as a
    # single character]
    strPriority = strPriority[:-1]
    # Create a new dictionary with the task and priority from the line that was just read
    # Then append the dictionary to the work list
    dictNew = {"Task": strTask, "Priority": strPriority}
    lstWork.append(dictNew)
print("Initial task list: " , lstWork, "\n")
fileHandle.close()


#Below are the functions that users can call at their option:

#To display data:
def DisplayData(lstWork):
    print("********Current Worklist************")
    for item in lstWork:
        #The loop below is to get the margins of the priorities to line up by correcting for the
        #number of characters in the task.  strNumSpaces is the number of spaces
        # between the last letter of the task
        #and the priority.
        intNumSpaces = 26 - len(item["Task"])
        strNumSpaces = ""
        for i in range(intNumSpaces):
            strNumSpaces += " "
        print(item["Task"]+strNumSpaces+ "("+item["Priority"]+")")
    print("************************************")

#To add a task:
def AddData():
    strNewTask = input("Enter a new task: ")
    strNewPriority = input("Enter the priority:  low = L, high = H: ")
    if strNewPriority.lower() == "h" or strNewPriority.lower() == "high":
        strNewPriority = "high"
    elif strNewPriority.lower() == "l" or strNewPriority.lower() == "low":
        strNewPriority = "low"
    else:
        print("Invalid priority.  Please start over.")
        #Exit the function if priority is not correctly entered (this happens before any data is
        #added to the list)
        return
    dictNew = {"Task": strNewTask, "Priority": strNewPriority}
    lstWork.append(dictNew)


#To remove an existing item
def DeleteTask(task, lstWork):
    for i in range(len(lstWork)):
        if lstWork[i]["Task"].lower() == task.lower():
            del lstWork[i]
            print("'"+task+"'"+" deleted.")
            #Exit the function if a task is deleted
            return
        #Error message if the task is not found in the lst:
    print("No such task exists.")


#To save the data to a text file
def SaveData(lstWork):
    fileHandle = open("Todo.txt", "w")
    for row in lstWork:
        fileHandle.write(row["Task"]+","+row["Priority"]+"\n")
    fileHandle.close()
    print("\nData saved in text file!\n")



#-------------------------Input / Output-------------------------------#
#Display the initial data to the user:
DisplayData(lstWork)

#The numbers 1 - 5 entered by the user call the appropriate functions
while True:
    print(
        "\nMenu:\n1) Show current data\n2) Add a new task\n3) Remove an existing item\n4)"
        " Save data to text file\n5) Exit program\n")
    try:
        intOptions = int(input("Enter the desired menu number: "))
        if intOptions == 1:
            DisplayData(lstWork)
        elif intOptions == 2:
            AddData()
        elif intOptions == 3:
            strTaskRemove = input("Enter the task to be removed: ")
            DeleteTask(strTaskRemove, lstWork)
        elif intOptions == 4:
            SaveData(lstWork)
        elif intOptions == 5:
            break
        elif intOptions < 1 or intOptions > 5:
            print("Invalid entry.  Please try again.")
    #the except block covers non-numeric entries
    except:
        print("Invalid entry.  Please try again.")

#------------------End of script---------------------------------------#