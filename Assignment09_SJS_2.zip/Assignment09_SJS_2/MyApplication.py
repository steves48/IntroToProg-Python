
#MyApplication.py module
"""
Title:  MyApplication
Dev:    SJSarewitz
Date:   12/16/2018
Desc:   This application manages employee data
ChangeLog:  (Who, When, What)
    SJSarewitz, 12/16/2018, Created

"""
if __name__ == "__main__":
    import NewCustomers, DataProcessor, Searches
else:
    raise Exception("This file was not created to be imported")

#------------------data-----------------------
#This is a flag--set to True if any data is entered under the option to add data.  If no data was
#typed in under the option to add data, and "done" is entered, the script skips the rest of the code except for the very last exit statement.
strDataPresent = False

objFile = None #A file object
strDecider = ""  #Is the option for searching the file or adding data to the file
IdNumberDecide = "" #Is the option for populating the Id field with the next number from the file, or not
IdNum = ""  #The customer ID number
strFirstName = ""  #Customer first name
strLastName = ""   #Customer last name
strPhoneNum = ""   #Customer phone number
strEMail = ""      #Customer email address
objC = None  #Customer object
objCL = None #List of Customer objects
lstFinished = ""  #Customer list converted to a string

#-----------------input/output----------------

print("Welcome to the Customer Record System.  Enter 'done' to quit.")
while True:
    strDecider = input(("To search for a record, type '1'; to quit, type 'done'; to add data, hit any other key."))
    if strDecider == "1":
        #The function that searches records by Id number, or first name, or last name
        Searches.SearchRecords()
    else:
        break
if strDecider.lower() != "done":
    #The following code adds data to the text file.
    #Pull the last ID number from the text file.  Users are asked if they want to use the next Id or enter their own Id (line 53)
    objFile = DataProcessor.File()
    intLastId = objFile.GetLastId()
    print("You can now add data to the system.")
    print("The last ID number was: ", str(intLastId))
    while True:
        IdNumDecide = input("Use the next ID number (y/n)? Hit any other key to end data entry. ")
        if IdNumDecide.lower() == "y":
            #If user wants to use default ID, the last ID no. is incremented and assigned to the
            #user ID
            intLastId += 1
            IdNum = str(intLastId)
        elif IdNumDecide.lower() == "n":
            IdNum = input("Enter your new Id number; OR type 'done' to end data entry. ")
        else:
            break
        if IdNum.lower() != "done":
            strFirstName = input("Enter the first name: ")
            strLastName = input("Enter the last name: ")
            strPhoneNum = input("Enter the phone number: ")
            strEmail = input("Enter the email: ")

            #Create instance of Customer class (objC) with Id number, phone number and email, inheriting FirstName and
            #LastName from Person class
            objC = NewCustomers.NewCustomer(IdNum,strPhoneNum,strEmail)
            objC.FirstName = strFirstName
            objC.LastName = strLastName
            #Create instance of CustomerList class to be a list of customer data
            objCL = NewCustomers.NewCustomerList()
            #Method to add the Customer data object to the Customer list object
            objCL.AddNewCustomer(objC)
            #The script exits if strDataPresent is not == True--which would be the case only if no data were entered (see line 82)
            strDataPresent = True
        else: break

    #If user has added data:
    if strDataPresent == True:
        #Print the data that the user has entered
        print("\nYou have added this data:\n" , objCL.ToString())
        #Create a string from the Customer list object.  Later (line 95), first part of the string
        #with the headers will be deleted before saving since the headers are not needed in the file.  We only want the
        #string from character no. 37 on--the header uses characters 0-36.

        lstFinished = objCL.ToString()
        strQuestion = input("Do you wish to save the data to the Customer file (y/n) ?")
        if strQuestion.lower() == "y":
            #create the file object from module DataProcessor, class File
            objFile = DataProcessor.File()
            #Create the text file to save, lopping off the headers
            objFile.TextData = lstFinished[37:]
            #method to add the data to the text file
            objFile.SaveData()
            print("Data saved to file.")

print("You have exited the Record System.")

