#Searches.py module--------------------
"""
Desc:  Searches text file for user data
Dev:  SJSarewitz
Date:  12/15/2018
ChangeLog:(When,Who,What):
    12/15/2018,SJSarewitz,Created
"""
#--------------------------------------

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself.")
else:
    import DataProcessor

def SearchRecords():
    #----------------------------------
    """
    Desc:  Searches text file for user data
    Dev:  SJSarewitz
    Date:  12/15/2018
    ChangeLog:(When,Who,What):
    12/15/2018,SJSarewitz,Created
    """
    #-----------Data-------------------
    #strChoice = type of search option
    #strItem = the data being searched for
    #strLocation = location of the data in the line in the text file
    #objFile = text file object
    #-----------Processing------------

    strChoice = input("Enter 1 to search by Id, or 2 to search by first OR last name: \n")
    if strChoice == "1" or strChoice == "2":
        if strChoice == "1":
            strItem = input("Enter the Id no.")
            strLocation = 0
        elif strChoice == "2":
            strItem = input("Enter the first OR last name: \n")
            strLocation = 1
        objFile = DataProcessor.File()
        #Method in DataProcessor module
        print(objFile.SearchItem(strItem,strLocation))
    else:
        print("Invalid entry.  Try again.")

