#NewCustomers.py module----------------------
"""
Desc:  Originally classes holding Employee data; modified to hold Customer data
Dev:  RRoot
Date: 12/15/2018
ChangeLog: (When,Who,What):
  12/15/2018,SJSarewitz,'Employee' changed to 'NewCustomer'; fields PhoneNum and Email added
"""
#--------------------------------------------

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself.")
else:
    import Persons

#Make child class
class NewCustomer(Persons.Person):
    """
    Class for Customer data
    """
    #----------------------------------------
    #Desc:  Holds customer data
    #Dev:  RRoot
    #Date: 12/15/2018
    #ChangeLog: (When,Who,What):
    #12/15/2018,SJSarewitz,'Employee' changed to 'NewCustomer'; fields PhoneNum and Email added
    #----------------------------------------

     #Fields
    #Id = Customer Id
    #PhoneNum = Customer phone number
    #Email = Customer email address

    #Constructor
    def __init__(self, Id="", PhoneNum="", Email=""):
        #Attributes
        self.Id = Id
        self.PhoneNum = PhoneNum
        self.Email = Email

    #Properties
    @property #getter or accessor
    def Id(self):
        return self.__Id

    @property #getter or accessor
    def PhoneNum(self):
        return self.__PhoneNum

    @property #getter or accessor
    def Email(self):
        return self.__Email

    @Id.setter #mutator or setter
    def Id(self, Value):
        self.__Id = Value

    @PhoneNum.setter #mutator or setter
    def PhoneNum(self, Value):
        self.__PhoneNum = Value

    @Email.setter #mutator or setter
    def Email(self, Value):
        self.__Email = Value

    #Methods

    def ToString(self):
        strData = super().ToString()
        return str(self.Id) + "," + strData + "," + str(self.PhoneNum) + "," + str(self.Email)

    def __str__(self):
        return self.ToString()

#End of NewCustomer class

class NewCustomerList(object):
    """Static class for holding a list of customer"""
    #--------------------------------------
    #Desc:  Manages list of Customer data
    #Dev:  RRoot
    #Date:  12/15/2018
    #ChangeLog:(When,Who,What):
        #12/15/2018,SJSarewitz,Changed 'Emplyee' to 'Customer'; added fields for phone number and email address
    #--------------------------------------
    __lstCustomers = []

    @staticmethod
    def AddNewCustomer(NewCustomer):
        if str(NewCustomer.__class__) == "<class 'NewCustomers.NewCustomer'>":
            NewCustomerList.__lstCustomers.append(NewCustomer)
        else:
            raise Exception ("Only new customer objects can be added to this list.")

    @staticmethod
    def ToString():
        strData = "Id,FirstName,LastName,PhoneNum,Email\n"
        for item in NewCustomerList.__lstCustomers:
            strData += str(item.Id) + "," + item.FirstName + "," + item.LastName + "," + str(item.PhoneNum) + "," + str(item.Email) + "\n"
        return strData

    @staticmethod
    def __str__():
        strData = NewCustomerList.ToString()
        return strData
    #End of NewCustomerList class