#DataProcessor.py module-------------------------
"""
Desc:  Classes that read and write data to/from a text file
Dev:  RRoot
Date: 12/15/2018
ChangeLog: (When,Who,What):
    12/15/2018,SJSarewitz, Added GetLastId and SearchItem methods
"""
#------------------------------------------------
if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself.")

class File(object):
    """Class to read and write data to/from a text file"""
    #------------------------------------------------
    #Desc:  Reads/writes data to/from a text file
    #Dev:  RRoot
    #Date:  12/15/2018
    #ChangeLog:(When,Who,What):
        #12/15/2018,SJSarewitz, Added GetLastId and SearchItem methods
    #------------------------------------------------

    #fields
    #FileName = name of file
    #TextData = data read from and written to file

    #Constructor

    def __init__(self, FileName = "SavedData.txt", TextData = ""):
        #Attributes
        self.FileName = FileName
        self.TextData = TextData

    #Properties

    @property  #getter or accessor
    def FileName(self):
        return self.__FileName

    @FileName.setter  #mutator or setter
    def FileName(self, Value):
        self.__FileName = Value

    @property  #getter or accessor
    def TextData(self):
        return self.__TextData

    @TextData.setter  #mutator or setter
    def TextData(self, Value):
        self.__TextData = Value

    #Methods

    def SaveData(self):
        try:
            objFile = open(self.FileName, "a")
            objFile.write(self.TextData)
            objFile.close()
        except Exception as e:
            print("error: " + str(e))
        return "Data Saved"

    def GetData(self):
        try:
            objFile = open(self.FileName, "r")
            self.TextData = objFile.read()
            objFile.close()
        except Exception as e:
            print("Error: ", str(e))

    def ToString(self):
        return self.__FileName + "," + self.__TextData

    def __str__(self):
        return self.ToString()()

    #This method finds the last Id number so it can be incremented for the next entry if the user so chooses.
    #if the text file does not yet exist, the last Id number is set to 0.
    def GetLastId(self):
        try:
            objFile = open(self.FileName, "r")
        except FileNotFoundError:  intLastNum = 0
        else:
            #find the last Id number in the file
            lstFile = objFile.readlines()
            strLastLine = lstFile[-1]
            lstLastItem = strLastLine.split(",")
            intLastNum = int(lstLastItem[0])
            objFile.close()
        return intLastNum

    #This method searches the text file by Id number, first name or last name
    @staticmethod
    def SearchItem(Item, Location):
        ItemLocated = False
        try:
            objFile = open("SavedData.txt", "r")
        except FileNotFoundError:  return "File does not exist."
        lstFile = objFile.readlines()
        for line in lstFile:
            lstLine = line.split(",")
            #Searching by Id number--index 0 of lstLine
            if Location == "0":
                if lstLine[int(Location)] == Item:
                    print(line)
                    ItemLocated = True
            #Searching by first Or last name--either index 1 or 2 of lstLine
            elif lstLine[int(Location)].lower() == Item.lower() or lstLine[int(Location)+1].lower() == Item.lower():
                    print(line)
                    ItemLocated = True
        objFile.close()
        if ItemLocated == False:
            return "No entry meeting search criteria identified.\n"
        else:
            return "Search completed.\n"



#end of class File