#Persons.py module----------------------
"""
Desc:  Classes that holds personal data
Dev:  RRoot
Date: 12/15/2018
ChangeLog: (When,Who,What):
  12/15/2018,RRoot,Created
"""
#---------------------------------------

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself.")

class Person(object):

    #Base class for personal data
    #------------------------------------
    """
    Desc:  Classe that holds personal data
    Dev:  RRoot
    Date: 12/15/2018
    ChangeLog: (When,Who,What):
      12/15/2018,RRoot,Created
    """
    #------------------------------------

    #Fields
    __Counter = 0

    #Constructor
    def __init__(self, FirstName, LastName):
        #Attributes
        self.FirstName = FirstName
        self.LastName = LastName
        Person.__SetObjectCount()  #a class attribute -- just one, not for objects

    #Properties

    @property #getter or accessor
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter #mutator or setter
    def FirstName(self, Value):
        self.__FirstName = Value

    @property  #getter or accessor
    def LastName(self):
        return self.__LastName

    @LastName.setter  #mutator or setter
    def LastName(self, Value):
        self.__LastName = Value

    #Methods

    def ToString(self):
        return self.__FirstName + "," + self.__LastName

    def __str__(self):
        return self.ToString()

    @staticmethod
    def GetObjectCount():
        return Person.__Counter

    @staticmethod
    def __SetObjectCount():
        Person.__Counter += 1

#End of Person class