"""
Title:  Assignment07_sjs_error_handling
Dev:  SJSarewitz
Date:  Nov.29,2018
Desc:  This script gives two examples of error handling.  It shows that if
an error is generated in the first example, the script doesn't crash but
continues on to the second example.
ChangeLog: (Who, What, When)
  SJSarewitz, Nov. 29, 2018, Created script
"""




#------Data------------
quotient = None
lstTest = ["Joe", "Bob", "Phil"]


#----------Processing and I/O------------

#First example:  Ask the user to enter 2 numbers to perform division

#First try block:  to catch non-numeric entries in dividend
try:
    fltDividend = float(input("Enter the dividend: "))
except ValueError:
    print("Error: only numeric entries are allowed.")
else:
    #Second try block:  to catch non-numeric entries in divisor
    try:
        fltDivisor = float(input("Enter the divisor: "))
    except ValueError:
        print("Error: only numeric entries are allowed.")
    else:
        #Third try block:  to catch division by zero
        try:
            quotient = fltDividend / fltDivisor
            print("The result is: ", quotient)
        except ZeroDivisionError:
            print("Error: you cannot divide by zero.")


#Second example:  Ask the user to enter the index of a list of names

nameSelect = input("Select the index of the name you wish to print: ")

#try block to detect non-numeric entries, entries that exceed the list range, and any
#other unusable entries (though I can't think of others that would not be trapped
#by either ValueError or IndexError)
try:
    intNameSelect = int(nameSelect)
    print(lstTest[intNameSelect])
except ValueError:
    print("Error:  Invalid list index.")
except IndexError:
    print("Error:  index exceeds list range")
except Exception as e:
    print("Python error: " + e.__str__())