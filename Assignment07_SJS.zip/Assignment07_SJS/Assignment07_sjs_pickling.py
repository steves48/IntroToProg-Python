"""
Title:  Assignment07_sjs_pickling
Dev:  SJSarewitz
Date:  Nov.29,2018
Desc:  This script gives examples of pickling data, writing it to a binary file,
and then reading / unpickling the data and displaying it.
ChangeLog: (Who, What, When)
  SJSarewitz, Nov. 29, 2018, Created script

"""

import pickle

#--------------Data--------------
strNewId = None
strNewName = None
#lstEntry will be a list containing one person's name & their ID entered by the user
lstEntry = None
#Each time the user inputs a person, a lstEntry list is appended to the lstNames list.
lstNames = []
#This list contains the data extracted from the binary file
lstOutput = []
#This string is for displaying the data from lstOutput
strRecord = "\n"



#--------------Processing---------
#Two functions, one to pickle & store data; one to unpickle & retrieve data:

#Store the data in a binary file (note that the second parameter is called "lstOfNames" to distinguish it from the
#argument "lstNames")
def StoreData(pFile, lstOfNames):
    objFile = open(pFile, "ab")
    for row in lstOfNames:
        #Each row in lstOfNames is a sublist with 2 elements: the ID number and the name
        #The data in the row is converted to a string to allow display formatting (see line 80 below)
        entry = str(row[0]) + row[1]
        pickle.dump(entry, objFile)
    objFile.close()

#retrieve the data for display
def RetrieveData(pFile):
    #This will be the list of data that is returned by the function
    lstOut = []
    objFile = open(pFile, "rb")
    while True:
        #This loop goes through the data in the binary file until no more data is found, which throws an error and
        #so the script exits the loop:
        try:
            objFileData = pickle.load(objFile)
            lstOut.append(objFileData)
        except EOFError:
            break
    objFile.close()
    return lstOut

#---------------Input / Output-------------
print("Type 'done' in the ID field when finished entering data.")
while True:
    strNewId = input("Enter the ID number: ")+", "
    if strNewId.lower() != "done, ":
        strNewName = input("Enter the name: ")
        lstEntry = [strNewId]
        lstEntry.append(strNewName)
        lstNames.append(lstEntry)
    else:
        break


print("You have entered the following: " , lstNames)

StoreData("NewCustomers.dat", lstNames)

lstOutput = RetrieveData("newCustomers.dat")

#This code formats and displays the data that was extracted from the binary file
for row in lstOutput:
    strRecord += row + "\n"
print(strRecord)