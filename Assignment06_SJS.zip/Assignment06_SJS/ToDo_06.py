"""

Title:  ToDo_06 List and text file, using a Class

Dev:  SJSarewitz

Date:  Noveember 25, 2018

Desc:  This script first writes two household tasks and
their priorities to a newly-created text file.  Then the data is extracted from the text file
and put in a list of dictionaries.  Each dictionary contains one task and its priority.
The script then gives the user the following options:
 1--Display the data in the list;
 2--Add new tasks to the list;
 3--Remove tasks from the list;
 4--Write the data in the list to the text file.
 5--Exit the script
The processes in this script are encapsulated in functions contained in
a Python Class, ManageList.

ChangeLog: (Who, What, When)
  SJSarewitz, Nov. 25, 2018, Created Script

"""

#--------------------Data--------------------------------#

lstWork = None
intOptions = None
dictNewEntry = None
strTaskRemove = None
strDecision = None

#--------------------Processing--------------------------#
#This is the class containing the functions used in the script:

class ManageList(object):

    @staticmethod
    def CreateTextFile(fileName = "Todo.txt"):
        """This function creates the text file with the initial entries"""
        objFile = open(fileName, "w")
        objFile.write("Clean house,low\n")
        objFile.write("Pay bills,high\n")
        objFile.close()

    @staticmethod
    def PopulateList(fileName = "Todo.txt"):
        """Populates the list with the initial data in the text file"""
        objFile = open(fileName, "r")
        lstTemp = []
        for line in objFile:
            strTask = line.split(",")[0]
            strPriority = line.split(",")[1]
            #Remove the \n from the end of the line:
            strPriority = strPriority[:-1]
            dictTemp = {"Task": strTask, "Priority": strPriority}
            lstTemp.append(dictTemp)
        objFile.close()
        return lstTemp

    @staticmethod
    def DisplayData(lst = lstWork):
        """Displays the data in the list of dictionaries (lstWork)"""
        print("********Current Worklist************")
        for item in lst:
            #The loop below is to get the margins of the priorities to line up by correcting for the
            #number of characters in the task.  strNumSpaces is the number of spaces
            # between the last letter of the task
            #and the priority.
            intNumSpaces = 26 - len(item["Task"])
            strNumSpaces = ""
            for i in range(intNumSpaces):
                strNumSpaces += " "
            print(item["Task"]+strNumSpaces+ "("+item["Priority"]+")")
        print("************************************")

    @staticmethod
    def AddData():
        """Adds data entered by the user to the list of dictionaries"""
        strNewTask = input("Enter a new task: ")
        strNewPriority = input("Enter the priority:  low = L, high = H: ")
        if strNewPriority.lower() == "h" or strNewPriority.lower() == "high":
            strNewPriority = "high"
        elif strNewPriority.lower() == "l" or strNewPriority.lower() == "low":
            strNewPriority = "low"
        else:
            print("Invalid priority.  Please start over.")
            #Exit the function if priority is not correctly entered (this happens before any data is
            #added to the list)
            return
        dictTemp = {"Task": strNewTask, "Priority": strNewPriority}
        return dictTemp

    @staticmethod
    def DeleteTask(task, lst):
        """To delete a task from the list"""
        for entry in lst:
            if entry["Task"].lower() == task.lower():
                lst.remove(entry)
                return lst
        print("No such task exists.")
        return

    @staticmethod
    def SaveData(lst):
        """To save the list to the text file"""
        objFile = open("Todo.txt", "w")
        for row in lst:
            objFile.write(row["Task"]+","+row["Priority"]+"\n")
        objFile.close()
        print("\nData saved in text file!\n")


#Create the text file and the list of dictionaries containing the
#initial data from the text file

ManageList.CreateTextFile()
lstWork = ManageList.PopulateList()
print(lstWork)

#-----------------------Input / Output---------------------------#

#Get input from the user for the various options 1 - 5

while True:
    print(
        "\nMenu:\n1) Show current data\n2) Add a new task\n3) Remove an existing item\n4)"
        " Save data to text file\n5) Exit program\n")

    try:
        intOptions = int(input("Enter the desired menu number: "))

        if intOptions == 1:
            ManageList.DisplayData(lstWork)
        elif intOptions == 2:
            dictNewEntry = ManageList.AddData()
            #This if statement needed because because if
            #an invalid priority is entered, the method AddData will return None
            if dictNewEntry != None:
                lstWork.append(dictNewEntry)
                print("New data added!")
        elif intOptions == 3:
            strTaskRemove = input("Enter the task to be removed: ")
            revisedLst = ManageList.DeleteTask(strTaskRemove, lstWork)
            #This if statement needed because method DeleteTask will return None if the task entered
            #by the user does not exist
            if revisedLst != None:
                print("Task removed!")
                lstWork = revisedLst
        elif intOptions == 4:
            print("Note:  the data in text file will be overwritten. ")
            strDecision = input("Do you wish to continue (y/n)? ")
            if strDecision.lower() == "y":
                ManageList.SaveData(lstWork)
            else:
                continue
        elif intOptions == 5:
            break
        elif intOptions < 1 or intOptions > 5:
            print("Invalid entry.  Please try again.")
    #the except block covers non-numeric entries
    except:
        print("Invalid entry.  Please try again.")


#----------------End of script---------------------#